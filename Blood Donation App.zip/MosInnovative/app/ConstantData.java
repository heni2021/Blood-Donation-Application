public class ConstantData {

    String PREF="pref";

}
