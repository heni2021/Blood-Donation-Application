package MOS.Innovative;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import June.Innovative.R;
public class ScheduleDonationActivity extends AppCompatActivity {

    EditText Adate,Atime;

    Button submit;
    Calendar calendar;
    SQLiteDatabase db1;

    SharedPreferences sp;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_donation);

        sp= getSharedPreferences(constantData.PREF,MODE_PRIVATE);
        Atime=findViewById(R.id.schedule_time);
        Adate=findViewById(R.id.schedule_date);

        calendar=Calendar.getInstance();


        submit=findViewById(R.id.schedule_submit_request);


        db1=openOrCreateDatabase("DonationRequest",MODE_PRIVATE,null);
        String tableQuery= "CREATE TABLE IF NOT EXISTS DONERS(USERID INTEGER PRIMARY KEY AUTOINCREMENT,NAME VARCHAR(100),EMAIL VARCHAR(100),CONTACT INT(10),DOB VARCHAR(10),GENDER VARCHAR(10),CITY VARCHAR(50),BLOODGROUP VARCHAR(50),ADATE VARCHAR(10),ATIME VATCHAR(50))";
        db1.execSQL(tableQuery);


        DatePickerDialog.OnDateSetListener dateClick= new DatePickerDialog.OnDateSetListener(){

            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                calendar.set(calendar.YEAR,i);
                calendar.set(calendar.MONTH,i1);
                calendar.set(calendar.DAY_OF_MONTH,i2);

                SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                Adate.setText(sdf.format(calendar.getTime()));
            }
        };
        Adate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dialog=new DatePickerDialog(ScheduleDonationActivity.this,dateClick,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
                //select past date--> max date
                //select future date--> min date
                dialog.getDatePicker().setMinDate(System.currentTimeMillis());
                dialog.show();

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Adate.getText().toString().trim().equals(""))
                {
                    Toast.makeText(ScheduleDonationActivity.this, "Please select date ", Toast.LENGTH_SHORT).show();
                }
                else if(Atime.getText().toString().trim().equals(""))
                {
                    Atime.setError("Mention available Time");
                }

                else
                {
                    String selectQuery= "SELECT * FROM DONERS WHERE USERID= '"+sp.getString(constantData.USERID,"")+"'  ";
                    Cursor cursor=db1.rawQuery(selectQuery,null);
                    if(cursor.getCount()>0)
                    {
                        Toast.makeText(ScheduleDonationActivity.this, "Already requested by you ", Toast.LENGTH_SHORT).show();


                    }
                    else {
                        String insertQuery = "INSERT INTO DONERS VALUES(NULL,'" + sp.getString(constantData.NAME,"") + "','" + sp.getString(constantData.EMAIL,"") + "', '" + sp.getString(constantData.CONTACT,"") + "','" + sp.getString(constantData.DOB,"") + "','" +sp.getString(constantData.GENDER,"") + "','" + sp.getString(constantData.CITY,"") + "' , '"+ sp.getString(constantData.BLOODGROUP,"")+"',  '"+Adate.getText().toString()+"', '"+Atime.getText().toString()+"'     )";
                        db1.execSQL(insertQuery);
                        Toast.makeText(ScheduleDonationActivity.this, "Requested Successfully", Toast.LENGTH_SHORT).show();
                        onBackPressed();


                    }
                }

            }
        });












    }
}