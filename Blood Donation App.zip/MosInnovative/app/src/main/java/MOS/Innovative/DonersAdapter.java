package MOS.Innovative;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import June.Innovative.R;
public class DonersAdapter extends RecyclerView.Adapter<DonersAdapter.DonerViewHolder> {

    private ArrayList<String> usernames;
    private ArrayList<Integer> contactNumbers;

    public DonersAdapter(ArrayList<String> usernames, ArrayList<Integer> contactNumbers) {
        this.usernames = usernames;
        this.contactNumbers = contactNumbers;
    }

    @NonNull
    @Override
    public DonerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_doners, parent, false);
        return new DonerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DonerViewHolder holder, int position) {
        String username = usernames.get(position);
        int contactNumber = contactNumbers.get(position);

        // Bind data to the views in the DonerViewHolder
        holder.usernameTextView.setText(username);
        holder.contactNumberTextView.setText(String.valueOf(contactNumber));
    }

    @Override
    public int getItemCount() {
        return usernames.size();
    }

    // DonerViewHolder class
    public static class DonerViewHolder extends RecyclerView.ViewHolder {
        TextView usernameTextView;
        TextView contactNumberTextView;

        public DonerViewHolder(@NonNull View itemView) {
            super(itemView);
            usernameTextView = itemView.findViewById(R.id.usernameTextView);
            contactNumberTextView = itemView.findViewById(R.id.contactNumberTextView);
        }
    }
}
