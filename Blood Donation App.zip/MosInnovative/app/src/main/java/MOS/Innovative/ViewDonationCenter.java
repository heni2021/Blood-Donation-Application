package MOS.Innovative;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import June.Innovative.R;
public class ViewDonationCenter extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DonationCentersAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_donation_center);

        // Find the RecyclerView in the layout
        recyclerView = findViewById(R.id.recyclerView);

        // Set up the layout manager for the RecyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Create an instance of the adapter
        adapter = new DonationCentersAdapter(getDonationCenters());

        // Set the adapter for the RecyclerView
        recyclerView.setAdapter(adapter);

    }

    private ArrayList<DonationCenter> getDonationCenters() {

        ArrayList<DonationCenter> donationCenters = new ArrayList<>();

        // Add sample donation centers
        donationCenters.add(new DonationCenter("Center 1", "Address 1", "Contact 1"));
        donationCenters.add(new DonationCenter("Center 2", "Address 2", "Contact 2"));
        donationCenters.add(new DonationCenter("Center 3", "Address 3", "Contact 3"));

        return donationCenters;
    }





}