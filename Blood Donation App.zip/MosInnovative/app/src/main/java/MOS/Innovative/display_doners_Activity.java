package MOS.Innovative;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.ArrayList;
import June.Innovative.R;
public class display_doners_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_doners);

        // Retrieve the intent extras
        Intent intent = getIntent();
        ArrayList<String> usernames = intent.getStringArrayListExtra("usernames");
        ArrayList<Integer> contactNumbers = intent.getIntegerArrayListExtra("contactNumbers");

        // Log the received data
        Log.d("display_doners", "Usernames: " + usernames);
        Log.d("display_doners", "Contact Numbers: " + contactNumbers);

        // Find the RecyclerView in the layout
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // Create and set up the adapter
        DonersAdapter adapter = new DonersAdapter(usernames, contactNumbers);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

}