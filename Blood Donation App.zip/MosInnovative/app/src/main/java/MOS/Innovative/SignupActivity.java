package MOS.Innovative;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import June.Innovative.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class SignupActivity extends AppCompatActivity {

    EditText name,email,password,confirmPassword,contact,dob;
    Button signup;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    Calendar calendar;
//    RadioButton male,female;
   RadioGroup gender;
   Spinner city,bloodgroup;

   String[] cityArray={ "Select city","Ahmedabad","Vadodara","Surat","Rajkot","Gandhinagar","Mehsana"};
    String[] bgArray={"Select Blood Group","A+","A-","B+","B-","O+","O-","AB+","AB-"};

   String sCity,sGender,sBloodGroup;

   SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        name= findViewById(R.id.sign_name);
        email=findViewById(R.id.sign_email);
        password=findViewById(R.id.sign_password);
        confirmPassword=findViewById(R.id.sign_confirm_password);
        contact=findViewById(R.id.sign_contact);
        dob=findViewById(R.id.sign_dob);
        gender=findViewById(R.id.signup_gender);
        city=findViewById(R.id.signup_city);
        bloodgroup=findViewById(R.id.signup_bg);
        //name,mode,cursor factory

       db=openOrCreateDatabase("Innovative",MODE_PRIVATE,null);
       String tableQuery= "CREATE TABLE IF NOT EXISTS USERS1(USERID INTEGER PRIMARY KEY AUTOINCREMENT,NAME VARCHAR(100),EMAIL VARCHAR(100),CONTACT INT(10),PASSWORD VARCHAR(20),DOB VARCHAR(10),GENDER VARCHAR(10),CITY VARCHAR(50),BLOODGROUP VARCHAR(50) ) ";
       db.execSQL(tableQuery);

        gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton=findViewById(i);
                sGender=  radioButton.getText().toString();
                Toast.makeText(SignupActivity.this,sGender, Toast.LENGTH_SHORT).show();
                
            }
        });


/*        male=findViewById(R.id.signup_male);
        female=findViewById(R.id.signup_female);

        male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SignupActivity.this,male.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });

        female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SignupActivity.this,female.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });*/

        ArrayAdapter adapter=new ArrayAdapter(SignupActivity.this, android.R.layout.simple_list_item_checked,cityArray);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        city.setAdapter(adapter);

        ArrayAdapter adapter2=new ArrayAdapter(SignupActivity.this, android.R.layout.simple_list_item_checked,bgArray);
        adapter2.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        bloodgroup.setAdapter(adapter2);

        city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(i==0)
                {
                    sCity= "";
                }
                else {
                    sCity=cityArray[i];
                    Toast.makeText(SignupActivity.this, sCity, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        bloodgroup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(i==0)
                {
                    sBloodGroup= "";
                }
                else {
                    sBloodGroup=bgArray[i];
                    Toast.makeText(SignupActivity.this, sBloodGroup, Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        calendar=Calendar.getInstance();


        signup=findViewById(R.id.sign_button);

        DatePickerDialog.OnDateSetListener dateClick= new DatePickerDialog.OnDateSetListener(){

            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                 calendar.set(calendar.YEAR,i);
                calendar.set(calendar.MONTH,i1);
                calendar.set(calendar.DAY_OF_MONTH,i2);

                SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                dob.setText(sdf.format(calendar.getTime()));
            }
        };
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dialog=new DatePickerDialog(SignupActivity.this,dateClick,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
                //select past date--> max date
                //select future date--> min date
                dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                dialog.show();

            }
        });


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(name.getText().toString().trim().equals(""))
                {
                    name.setError("Name required");
                }

                if(email.getText().toString().trim().equals(""))
                {
                    email.setError("Email Id required");
                }

                else if(!email.getText().toString().trim().matches(emailPattern))
                {
                    email.setError("Valid Email Id required");
                }

                else if(contact.getText().toString().trim().equals(""))
                {
                    contact.setError("Contact No. required");
                }

                else if(contact.getText().toString().trim().length()<10)
                {
                    contact.setError("Valid Contact required");
                }

                else if(password.getText().toString().trim().equals(""))
                {
                    password.setError("Password required");
                }

                else if(password.getText().toString().trim().length()<6)
                {
                    password.setError("Min. 6 char password required");
                }

                else if(confirmPassword.getText().toString().trim().equals(""))
                {
                    confirmPassword.setError("Confirm Password required");
                }

                else if(confirmPassword.getText().toString().trim().length()<6)
                {
                    confirmPassword.setError("Min. 6 char confirm password required");
                }

                else if(!confirmPassword.getText().toString().matches(password.getText().toString()))
                {
                    confirmPassword.setError("Confirm Password Does Not Match");
                }

                else if(dob.getText().toString().trim().equals(""))
                {
                    Toast.makeText(SignupActivity.this, "Please select date of birth", Toast.LENGTH_SHORT).show();
                }

                else if(gender.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(SignupActivity.this, "Please Select Gender", Toast.LENGTH_SHORT).show();
                }

                else if(sCity.equals("")){
                    Toast.makeText(SignupActivity.this, "Please Select City", Toast.LENGTH_SHORT).show();

                }

                else if(sBloodGroup.equals("")){
                    Toast.makeText(SignupActivity.this, "Please Select Blood Group ", Toast.LENGTH_SHORT).show();

                }

                else
                {
                    String selectQuery= "SELECT * FROM USERS1 WHERE EMAIL= '"+email.getText().toString()+"' OR CONTACT='"+contact.getText().toString()+"' ";
                    Cursor cursor=db.rawQuery(selectQuery,null);
                    if(cursor.getCount()>0)
                    {
                        Toast.makeText(SignupActivity.this, "Email/Contact Already Registered", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        String insertQuery = "INSERT INTO USERS1 VALUES(NULL,'" + name.getText().toString() + "','" + email.getText().toString() + "', '" + contact.getText().toString() + "','" + password.getText().toString() + "','" + dob.getText().toString() + "','" + sGender + "','" + sCity + "' ,'"+sBloodGroup+"')";
                        db.execSQL(insertQuery);
                        Toast.makeText(SignupActivity.this, "Signup Successfully", Toast.LENGTH_SHORT).show();
                        onBackPressed();
                    }
                }

            }
        });
    }
}