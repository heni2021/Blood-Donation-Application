package MOS.Innovative;

/*public class DonationCentersAdapter {
}*/

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;import June.Innovative.R;

public class DonationCentersAdapter extends RecyclerView.Adapter<DonationCentersAdapter.ViewHolder> {

    private List<DonationCenter> donationCenters;

    public DonationCentersAdapter(List<DonationCenter> donationCenters) {
        this.donationCenters = donationCenters;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_donation_center, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DonationCenter donationCenter = donationCenters.get(position);
        holder.bind(donationCenter);
    }

    @Override
    public int getItemCount() {
        return donationCenters.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView nameTextView;
        private TextView addressTextView;
        private TextView contactTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.donation_center_name);
            addressTextView = itemView.findViewById(R.id.donation_center_address);
            contactTextView = itemView.findViewById(R.id.donation_center_contact);
        }

        public void bind(DonationCenter donationCenter) {
            nameTextView.setText(donationCenter.getName());
            addressTextView.setText(donationCenter.getAddress());
            contactTextView.setText(donationCenter.getContactNumber());
        }
    }
}

