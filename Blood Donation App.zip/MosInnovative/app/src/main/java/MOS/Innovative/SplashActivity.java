package MOS.Innovative;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import June.Innovative.R;

public class SplashActivity extends AppCompatActivity {

    SharedPreferences sp;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sp = getSharedPreferences(constantData.PREF, MODE_PRIVATE);
        imageView = findViewById(R.id.splash_iv);

//        Picasso.get().load("https://odishanewstoday.com/wp-content/uploads/2021/05/Heart-Article-Hero-1200x500.gif").placeholder(R.mipmap.ic_launcher).into(imageView);
//        Glide.with(SplashActivity.this).asGif().load("https://media.tenor.com/IkWXV2_DMNAAAAAM/giving-blood-donating-blood.gif");
//        Glide.with(SplashActivity.this).asGif().load("https://i.pinimg.com/originals/67/d0/13/67d0137c6517d5ed0fcc461f2582dcfd.gif").placeholder(R.mipmap.ic_launcher).into(imageView);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (sp.getString(constantData.USERID, "").equalsIgnoreCase("")) {
                    Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(SplashActivity.this, DashboardActivity2.class);
                    startActivity(intent);
                    finish();

                }
            }
        }, 2000);
    }
    }
