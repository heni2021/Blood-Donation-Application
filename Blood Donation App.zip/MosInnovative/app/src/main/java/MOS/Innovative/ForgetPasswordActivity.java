package MOS.Innovative;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import June.Innovative.R;

public class ForgetPasswordActivity extends AppCompatActivity {

    EditText email,password,confirmPassword;
    Button continueButton,submitButton;

    SQLiteDatabase db;

    SharedPreferences sp;

    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        db=openOrCreateDatabase("Innovative",MODE_PRIVATE,null);
        String tableQuery= "CREATE TABLE IF NOT EXISTS USERS1(USERID INTEGER PRIMARY KEY AUTOINCREMENT,NAME VARCHAR(100),EMAIL VARCHAR(100),CONTACT INT(10),PASSWORD VARCHAR(20),DOB VARCHAR(10),GENDER VARCHAR(10),CITY VARCHAR(50))";
        db.execSQL(tableQuery);

        email= findViewById(R.id.forgot_password_email);
        password=findViewById(R.id.forgot_password);
        confirmPassword=findViewById(R.id.forgot_confirm_password);

        continueButton=findViewById(R.id.forgot_password_continue);
        submitButton=findViewById((R.id.forgot_password_submit));

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(email.getText().toString().trim().equals(""))
                {
                    email.setError("Email Id required");
                }

                else if(!email.getText().toString().trim().matches(emailPattern))
                {
                    email.setError("Valid Email Id required");
                }

                else{

                    String selectQuery= " SELECT * FROM USERS1 WHERE EMAIL='"+email.getText().toString()+"'    ";
                    Cursor cursor=db.rawQuery(selectQuery,null);
                    if(cursor.getCount()>0) {
                        email.setEnabled(false);
                        password.setVisibility(view.VISIBLE);
                        confirmPassword.setVisibility((view.VISIBLE));

                        continueButton.setVisibility(view.GONE);
                        submitButton.setVisibility(view.VISIBLE);
                    }
                    else {
                        Toast.makeText(ForgetPasswordActivity.this, "Invalid Email Id", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(password.getText().toString().trim().equals(""))
                {
                    password.setError("Password required");
                }

                else if(confirmPassword.getText().toString().trim().equals(""))
                {
                    confirmPassword.setError("Confirm Password required");
                }

                else if(password.getText().toString().trim().length()<6)
                {
                    password.setError("Min. 6 char password required");
                }

                else if(confirmPassword.getText().toString().trim().length()<6)
                {
                    confirmPassword.setError("Min. 6 char confirm password required");
                }

                else if(!confirmPassword.getText().toString().matches(password.getText().toString()))
                {
                    confirmPassword.setError("Confirm Password Does Not Match");
                }

                else {
                    String updateQuery = "UPDATE USERS1 SET PASSWORD='"+password.getText().toString()+"' WHERE EMAIL= '"+email.getText().toString()+"'            ";
                    db.execSQL(updateQuery);

                    Toast.makeText(ForgetPasswordActivity.this, "Password Change Successfully", Toast.LENGTH_SHORT).show();
                    onBackPressed();
                }



            }
        });



    }
}