package MOS.Innovative;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


import java.util.ArrayList;

import June.Innovative.R;
public class HomeFragment extends Fragment {




    SharedPreferences sp;
    RadioGroup BloodGroup;

    Button redirectButton;
    String sBloodGroup;

    SQLiteDatabase db;



    public HomeFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home, container, false);
        sp=getActivity().getSharedPreferences(constantData.PREF, Context.MODE_PRIVATE);

        BloodGroup=view.findViewById(R.id.home_blood_group);
        redirectButton=view.findViewById(R.id.redirect_button);


        BloodGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton=getActivity().findViewById(i);
                sBloodGroup=  radioButton.getText().toString();
                Toast.makeText(getActivity(),sBloodGroup,Toast.LENGTH_SHORT).show();

             /*   Intent intent= new Intent(getActivity(), display_doners_Activity.class);
                startActivity(intent);*/


            }
        });


        redirectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(BloodGroup.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(getActivity(), "Please Select Blood group", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    SQLiteDatabase db = getActivity().openOrCreateDatabase("Innovative", Context.MODE_PRIVATE, null);
                    String tableQuery= "CREATE TABLE IF NOT EXISTS USERS1(USERID INTEGER PRIMARY KEY AUTOINCREMENT,NAME VARCHAR(100),EMAIL VARCHAR(100),CONTACT INT(10),PASSWORD VARCHAR(20),DOB VARCHAR(10),GENDER VARCHAR(10),CITY VARCHAR(50),BLOODGROUP VARCHAR(50) ) ";
                    db.execSQL(tableQuery);

                    String selectQuery= "SELECT * FROM USERS1 WHERE BLOODGROUP= '"+sBloodGroup+"'  ";
                    Cursor cursor=db.rawQuery(selectQuery,null);
                    if(cursor.getCount()>0)
                    {
                        ArrayList<String> usernames = new ArrayList<>();
                        ArrayList<Integer> contactNumbers = new ArrayList<>();



                        while (cursor.moveToNext()) {
                            /*int nameColumnIndex = cursor.getColumnIndex("NAME");
                            int contactColumnIndex = cursor.getColumnIndex("CONTACT");
                            Log.d("Column Index", "Name Column Index: " + nameColumnIndex + ", Contact Column Index: " + contactColumnIndex);*/
                            String username = cursor.getString(1);
                            int contactNumber = cursor.getInt(3);



                            usernames.add(username);
                            contactNumbers.add(contactNumber);
                        }

                        // Pass the data to the new activity
                        Log.d("HomeFragment", "Usernames list: " + usernames.toString());

// Log the contents of `contactNumbers` list
                        Log.d("HomeFragment", "Contact Numbers list: " + contactNumbers.toString());

                        Intent intent = new Intent(getActivity(), display_doners_Activity.class);
                        intent.putStringArrayListExtra("usernames", usernames);
                        intent.putIntegerArrayListExtra("contactNumbers", contactNumbers);
                        startActivity(intent);
                    }
                    else {

                        Toast.makeText(getActivity(), "No blood unit available", Toast.LENGTH_SHORT).show();

                    }
                }





            }
        });




        return view;
    }
}