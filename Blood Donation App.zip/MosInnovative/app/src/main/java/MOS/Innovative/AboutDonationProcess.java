package MOS.Innovative;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import June.Innovative.R;

public class AboutDonationProcess extends AppCompatActivity {

    private TextView titleTextView;
    private TextView descriptionTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_donation_process);
        titleTextView = findViewById(R.id.title_text_view);
        descriptionTextView = findViewById(R.id.description_text_view);

        titleTextView.setText("About Blood Donation");
        descriptionTextView.setText("              Blood donation is a voluntary procedure where individuals give their blood to a blood bank or donation center. The donated blood is used for various medical treatments and emergencies. Donating blood is a noble act that can save lives and contribute to the well-being of others. If you are eligible and willing to donate blood, please reach out to your nearest blood donation center or hospital.");
    }

}