package MOS.Innovative;

public class constantData {

    public static String PREF="pref";

    public static String USERID="userid";
    public static String NAME="name";
    public static String EMAIL="email";
    public static String CONTACT="contact";
    public static String PASSWORD="password";
    public static String DOB="dob";
    public static String GENDER="gender";
    public static String CITY="city";

    public static String BLOODGROUP="bloodgroup";



}
